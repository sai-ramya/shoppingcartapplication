package com.mindtree.ShopApp.service;

import java.util.List;

import com.mindtree.ShopApp.common.PriceProduct;
import com.mindtree.ShopApp.exception.ProductNotFoundException;
import com.mindtree.ShopApp.exception.QuantityShouldNotNegative;
import com.mindtree.ShopApp.exception.UserIdNotFound;
import com.mindtree.ShopApp.modelDto.ProductDto;

public interface CartService {

	String addProductToCart(int userId, ProductDto product) throws UserIdNotFound;

	PriceProduct getUserTotalAmount(int userId) throws UserIdNotFound;

	String updateTheQuantity(int userId, int quantity, int productId) throws UserIdNotFound, QuantityShouldNotNegative, ProductNotFoundException;

	String deleteProduct(List<Integer> productIds, int userId) throws UserIdNotFound, ProductNotFoundException;

	String deleteAllProducts(int userId) throws UserIdNotFound;

	ProductDto getProductOnProductName(String productName) throws ProductNotFoundException;

	ProductDto getProductById(int productId) throws ProductNotFoundException;

	List<ProductDto> getProductsByCategory(String productCategory) throws ProductNotFoundException;

}
