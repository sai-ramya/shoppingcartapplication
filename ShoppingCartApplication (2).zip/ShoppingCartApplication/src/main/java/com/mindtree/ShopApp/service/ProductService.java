package com.mindtree.ShopApp.service;

public interface ProductService {

}
