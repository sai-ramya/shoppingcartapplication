package com.mindtree.ShopApp.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Cart {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int cartId;
	private String cartName;
	@OneToMany(cascade = { CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH,
			CascadeType.REMOVE }, mappedBy = "productCart", orphanRemoval = true)
	private List<Product> cartProducts;
	@OneToOne
	private User user;

	public Cart() {
		// TODO Auto-generated constructor stub
	}

	public Cart(int cartId, String cartName, List<Product> cartProducts, User user) {
		super();
		this.cartId = cartId;
		this.cartName = cartName;
		this.cartProducts = cartProducts;
		this.user = user;
	}

	public List<Product> getCartProducts() {
		return cartProducts;
	}

	public void setCartProducts(List<Product> cartProducts) {
		this.cartProducts = cartProducts;
	}

	public User getUser() {
		return user;
	}

	public void setCartUser(User user) {
		this.user = user;
	}

	public int getCartId() {
		return cartId;
	}

	public void setCartId(int cartId) {
		this.cartId = cartId;
	}

	public String getCartName() {
		return cartName;
	}

	public void setCartName(String cartName) {
		this.cartName = cartName;
	}

}
