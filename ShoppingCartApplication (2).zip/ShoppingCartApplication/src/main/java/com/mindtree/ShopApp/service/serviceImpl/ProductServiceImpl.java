package com.mindtree.ShopApp.service.serviceImpl;

import org.springframework.stereotype.Service;

import com.mindtree.ShopApp.service.ProductService;

@Service
public class ProductServiceImpl implements ProductService{

	public ProductServiceImpl() {
		// TODO Auto-generated constructor stub
	}

}
