package com.mindtree.ShopApp.common;

import java.util.List;

import com.mindtree.ShopApp.modelDto.ProductDto;

public class PriceProduct 
{
	private List<ProductDto> productDto;
	private double price;
	public List<ProductDto> getProductDto() {
		return productDto;
	}
	public void setProductDto(List<ProductDto> productDto) {
		this.productDto = productDto;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public PriceProduct() {
		super();
		// TODO Auto-generated constructor stub
	}
}
